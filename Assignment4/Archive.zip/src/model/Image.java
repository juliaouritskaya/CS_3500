package model;

/**
 * This interface represents an image, which is a sequence of pixels.
 */
public interface Image {
  /**
   * Flips the image horizontally by flipping its pixel composition.
   */
  public void flipHorizontal();

  /**
   * Flips the image vertically by flipping its pixel composition.
   *
   * @return
   */
  public void flipVertical();

  /**
   * Method to brighten or darken and image.
   * @param component how much you want the image to be lightened or darkened.
   */
  public void brighten(int component);

  /**
   * Method to turn an image into greyscale using intensity.
   */
  public void intensity();

  /**
   * Method to turn an image into greyscale using the red component.
   */
  public void redComponent();

  /**
   * Method to turn an image into greyscale using the green component.
   */
  public void greenComponent();

  /**
   * Method to turn an image into greyscale using the blue component.
   */
  public void blueComponent();

  /**
   * Method to turn an image into greyscale using luma.
   */
  public void luma();

  /**
   * Method to turn an image into greyscale using the highest value component.
   */
  void value();

  /**
   * Returns the pixels that make up the image.
   * @return the pixels that make up the image
   */
  public Pixel[][] getPixels();

  /**
   * Returns the pixel at the specified position.
   * @param row the row position of the pixel
   * @param col the column positon of the pixel
   * @return the pixel at the specified row and column
   */
  public Pixel getPixelAt(int row, int col);

  /**
   * Returns the width of the image.
   * @return the width of the image
   */
  public int getWidth();

  /**
   * Returns the height of the image.
   * @return the height of the image
   */
  public int getHeight();
}
