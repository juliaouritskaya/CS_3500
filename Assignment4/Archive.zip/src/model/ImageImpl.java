package model;

/**
 * This class represents an image, with corresponding pixels, width, and height.
 */
public class ImageImpl implements Image {
  private Pixel[][] pixels;
  protected int width;
  protected int height;

  /**
   * Creates an instance of an image with specified pixels, width, and height.
   *
   * @param pixels the 2D array representing the pixels that make up the image
   * @throws IllegalArgumentException if the parameters are null or negative
   */
  public ImageImpl(Pixel[][] pixels) throws IllegalArgumentException {
    if (pixels == null || pixels[0].length < 1) {
      throw new IllegalArgumentException("Pixels must be non-null and contain elements.");
    } else {
      for (int col = 0; col < pixels.length; col++) {
        if (pixels[col].length != pixels[0].length) {
          throw new IllegalArgumentException("Number of pixels in each row is not the same.");
        } else {
          this.width = pixels[0].length;
          this.height = pixels.length;
          this.pixels = pixels;
        }
      }
    }
  }

  /**
   * Flips the image vertically by flipping its pixel composition.
   */
  @Override
  public void flipVertical() {
    for (int col = 0; col < this.width; col++) {
      int first = 0;
      int last = this.height - 1;

      while (first < last) {
        Pixel temp = this.pixels[first][col];
        this.pixels[first][col] = this.pixels[last][col];
        this.pixels[last][col] = temp;
        first++;
        last--;
      }
    }
  }

  @Override
  public void flipHorizontal() {
    for (int row = 0; row < this.height; row++) {
      int first = 0;
      int last = this.width - 1;

      while (first < last) {
        Pixel temp = this.pixels[row][first];
        this.pixels[row][first] = this.pixels[row][last];
        this.pixels[row][last] = temp;
        first++;
        last--;
      }
    }
  }

  /**
   * Method to brighten or darken and image.
   *
   * @param component how much you want the image to be lightened or darkened.
   */
  @Override
  public void brighten(int component) {
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        if (pixels[col][row].getBlue() + component > 255
                || pixels[col][row].getBlue() + component < 0
                || pixels[col][row].getRed() + component > 255
                || pixels[col][row].getRed() + component < 0
                || pixels[col][row].getGreen() + component > 255
                || pixels[col][row].getGreen() + component < 0) {
          throw new IllegalArgumentException("Component's magnitude is too large.");
        }
      }
    }
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        pixels[col][row].red += component;
        pixels[col][row].blue += component;
        pixels[col][row].green += component;

      }
    }
  }

  /**
   * Method to turn an image into greyscale using intensity.
   */
  @Override
  public void intensity() {
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        int average = 0;
        average += pixels[col][row].getRed();
        average += pixels[col][row].getBlue();
        average += pixels[col][row].getGreen();

        int result = Math.round(average / 3); // the round is needed for integer division

        pixels[col][row].red = result;
        pixels[col][row].blue = result;
        pixels[col][row].green = result;

      }
    }
  }

  /**
   * Method to turn an image into greyscale using the red component.
   */
  @Override
  public void redComponent() {
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        int comp = pixels[col][row].getRed();

        pixels[col][row].blue = comp;
        pixels[col][row].green = comp;

      }
    }
  }

  /**
   * Method to turn an image into greyscale using the green component.
   */
  @Override
  public void greenComponent() {
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        int comp = pixels[col][row].getGreen();

        pixels[col][row].red = comp;
        pixels[col][row].blue = comp;
      }
    }
  }

  /**
   * Method to turn an image into greyscale using the blue component.
   */
  @Override
  public void blueComponent() {
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        int comp = pixels[col][row].getBlue();
        pixels[col][row].red = comp;
        pixels[col][row].green = comp;
      }
    }
  }

  /**
   * Method to turn an image into greyscale using luma.
   */
  @Override
  public void luma() {
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        int average = (int) (pixels[col][row].blue * 0.0722
                + pixels[col][row].red * 0.2126
                + pixels[col][row].green * 0.7152);
        pixels[col][row].red = average;
        pixels[col][row].green = average;
        pixels[col][row].blue = average;
      }
    }
  }


  /**
   * Method to turn an image into greyscale using the highest value component.
   */
  @Override
  public void value() {
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        int temp = Math.max(pixels[col][row].blue,
                pixels[col][row].red);
        int max = Math.max(temp, pixels[col][row].green);

        pixels[col][row].red = max;
        pixels[col][row].green = max;
        pixels[col][row].blue = max;
      }
    }
  }

  /**
   * Returns the pixels that make up the image.
   *
   * @return the pixels that make up the image
   */
  @Override
  public Pixel[][] getPixels() {
    return this.pixels;
  }

  /**
   * Returns the pixel at the specified position.
   *
   * @param row the row position of the pixel
   * @param col the column positon of the pixel
   * @return the pixel at the specified row and column
   */
  @Override
  public Pixel getPixelAt(int row, int col) {
    if (row < 0 || row > this.width || col < 0 || col > this.height) {
      throw new IllegalArgumentException("Invalid pixel.");
    } else {
      return this.pixels[row][col];
    }
  }

  /**
   * Returns the width of the image.
   *
   * @return the width of the image
   */
  @Override
  public int getWidth() {
    return this.width;
  }

  /**
   * Returns the height of the image.
   *
   * @return the height of the image
   */
  @Override
  public int getHeight() {
    return this.height;
  }

  /**
   * Return a string that represents the current state of the image.
   *
   * @return the image state as a string
   */
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.width + " ");
    stringBuilder.append(this.height + "\n");
    for (int i = 0; i < this.height; i++) {
      for (int j = 0; j < this.width; j++) {
        if (j < this.height - 1) {
          stringBuilder.append(this.pixels[i][j].toString()).append(" ");
        } else {
          stringBuilder.append(this.pixels[i][j].toString()).append("\n");
        }
      }
    }
    return stringBuilder.toString();
  }
}


