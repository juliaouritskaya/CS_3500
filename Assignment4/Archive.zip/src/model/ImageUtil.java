package model;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileInputStream;

/**
 * This class contains utility methods to read a PPM image from file and simply print its contents.
 * Feel free to change this method as required.
 */
public class ImageUtil {

  /**
   * Read an image file in the PPM format and print the colors.
   *
   * @param filename the path of the file.
   */
  public static Image readPPM(File filename) {
    Scanner sc;

    try {
      sc = new Scanner(new FileInputStream(filename));
    } catch (FileNotFoundException e) {
      System.out.println("File " + filename + " not found!");
      return null;
    }
    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }
    int width = sc.nextInt();
    System.out.println("Width of image: " + width);
    int height = sc.nextInt();
    System.out.println("Height of image: " + height);
    int maxValue = sc.nextInt();
    System.out.println("Maximum value of a color in this file (usually 255): " + maxValue);

    Pixel[][] pixels = new Pixel[width][height];

    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        pixels[j][i] = new Pixel(r, g, b);
        //System.out.println("Color of pixel ("+j+","+i+"): "+ r+","+g+","+b);
      }
    }

    return new ImageImpl(pixels);
  }

  /**
   * Write an image file in the PPM format.
   *
   * @param fileName the path of the file.
   * @param image the image to write.
   */
  public static void writePPM(String fileName, Image image) {
    try {
      Pixel[][] pixels = image.getPixels();
      int width = pixels.length;
      int height = pixels[0].length;

      FileWriter fwriter = new FileWriter(fileName);

      fwriter.write("P3\n");
      fwriter.write("# Created by CS3500 students Julia Ouritskaya and Evelyn Robert\n");
      fwriter.write(String.valueOf(width));
      fwriter.write(' ');
      fwriter.write(String.valueOf(height));
      fwriter.write('\n');
      fwriter.write(String.valueOf(255));
      fwriter.write('\n'); // max val

      for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
          fwriter.write(String.valueOf(pixels[j][i].getRed()));
          fwriter.write('\n');
          fwriter.write(String.valueOf(pixels[j][i].getGreen()));
          fwriter.write('\n');
          fwriter.write(String.valueOf(pixels[j][i].getBlue()));
          fwriter.write('\n');
        }
      }
      fwriter.close();
    } catch (IOException e) {
      System.out.println("An error occurred");
      throw new IllegalStateException("An file write error occurred");
    }
  }

  /**
   * main method of the program.
   *
   * @param args any command line arguments
   */
  public static void main(String[] args) {
    String filename;
    File file;


    if (args.length > 0) {
      filename = args[0];
      file = new File(filename);
    } else {
      filename = "sample.ppm";
      file = new File(filename);
    }

    Image image = ImageUtil.readPPM(file);
    ImageUtil.writePPM("O_" + filename, image);
  }
}

