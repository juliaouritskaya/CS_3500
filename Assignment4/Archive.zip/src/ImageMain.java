import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

import controller.ImageController;

/**
 * The driver of this application.
 */
public class ImageMain {
  /**
   * main method of the program.
   *
   * @param args any command line arguments
   */
  public static void main(String []args) {
    String filename;
    File file;

    if (args.length > 0) {
      filename = args[0];
      file = new File(filename);
    }
    else {
      filename = "sample.ppm";
      file = new File(filename);
    }

    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    ImageController controller = new ImageController(in, System.out);

    controller.control();
  }
}
