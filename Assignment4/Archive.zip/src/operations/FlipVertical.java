package operations;

import model.Image;

/**
 * This class creates an image flipped vertically.
 */
public class FlipVertical implements ImageOperationCommand {
  /**
   * Takes in an image object and executes the flip vertical operation on it.
   *
   * @param image the image object passed in
   */
  @Override
  public void execute(Image image) {
    image.flipVertical();
  }
}
