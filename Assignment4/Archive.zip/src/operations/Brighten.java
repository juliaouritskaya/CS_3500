package operations;

import model.Image;

/**
 * This class creates an image that is brighter or darker based on the inputted component.
 */
public class Brighten implements ImageOperationCommand {
  private int component;

  public Brighten(int component) {
    this.component = component;
  }

  /**
   * Takes in an image object and executes this operation on it.
   *
   * @param image the image object passed in
   */
  @Override
  public void execute(Image image) {
    image.brighten(this.component);
  }
}
