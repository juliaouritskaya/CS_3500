package operations;

import model.Image;

/**
 * This class creates a grey scale of an image using the blue component.
 */
public class BlueComponent implements ImageOperationCommand {
  /**
   * Takes in an image object and executes this operation on it.
   *
   * @param image the image object passed in
   */
  @Override
  public void execute(Image image) {
    image.blueComponent();
  }
}
