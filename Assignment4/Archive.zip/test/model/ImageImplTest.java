package model;

import org.junit.Test;

import java.io.File;
import java.io.StringReader;
import controller.ImageController;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This class represents tests for an image.
 */
public class ImageImplTest {
  private Pixel a = new Pixel(1, 2, 3);
  private Pixel b = new Pixel(4, 5, 6);
  private Pixel c = new Pixel(7, 8, 9);
  private Pixel d = new Pixel(11, 12, 13);
  private Pixel e = new Pixel(14, 15, 16);
  private Pixel f = new Pixel(17, 18, 19);
  private Pixel g = new Pixel(21, 22, 23);
  private Pixel h = new Pixel(24, 25, 26);
  private Pixel i = new Pixel(27, 28, 29);

  private Pixel [][] pixels = {
          {a, b, c},
          {d, e, f},
          {g, h, i}
  };

  Image image = new ImageImpl(pixels);


  @Test
  public void testToString() {
    assertEquals("3 3\n" +
            "(R:1, G:2, B:3) (R:4, G:5, B:6) (R:7, G:8, B:9)\n" +
            "(R:11, G:12, B:13) (R:14, G:15, B:16) (R:17, G:18, B:19)\n" +
            "(R:21, G:22, B:23) (R:24, G:25, B:26) (R:27, G:28, B:29)\n", image.toString());
  }

  @Test
  public void testBrighten() {
    image.brighten(10);
    assertEquals("3 3\n" +
            "(R:11, G:12, B:13) (R:14, G:15, B:16) (R:17, G:18, B:19)\n" +
            "(R:21, G:22, B:23) (R:24, G:25, B:26) (R:27, G:28, B:29)\n" +
            "(R:31, G:32, B:33) (R:34, G:35, B:36) (R:37, G:38, B:39)\n", image.toString());
  }

  @Test (expected = IllegalArgumentException.class)
  public void testBrightenFail() {
    image.brighten(-10);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testBrightenFail2() {
    image.brighten(250);
  }

  @Test
  public void testFlipVertical() {
    image.flipVertical();
    assertEquals("3 3\n" +
            "(R:21, G:22, B:23) (R:24, G:25, B:26) (R:27, G:28, B:29)\n" +
            "(R:11, G:12, B:13) (R:14, G:15, B:16) (R:17, G:18, B:19)\n" +
            "(R:1, G:2, B:3) (R:4, G:5, B:6) (R:7, G:8, B:9)\n", image.toString());

  }

  @Test
  public void testFlipHorizontal() {
    image.flipHorizontal();
    assertEquals("3 3\n" +
            "(R:7, G:8, B:9) (R:4, G:5, B:6) (R:1, G:2, B:3)\n" +
            "(R:17, G:18, B:19) (R:14, G:15, B:16) (R:11, G:12, B:13)\n" +
            "(R:27, G:28, B:29) (R:24, G:25, B:26) (R:21, G:22, B:23)\n", image.toString());
  }

  @Test
  public void testBlueComponent() {
    image.blueComponent();
    assertEquals("3 3\n" +
            "(R:3, G:3, B:3) (R:6, G:6, B:6) (R:9, G:9, B:9)\n" +
            "(R:13, G:13, B:13) (R:16, G:16, B:16) (R:19, G:19, B:19)\n" +
            "(R:23, G:23, B:23) (R:26, G:26, B:26) (R:29, G:29, B:29)\n", image.toString());
  }

  @Test
  public void testRedComponent() {
    image.redComponent();
    assertEquals("3 3\n" +
            "(R:1, G:1, B:1) (R:4, G:4, B:4) (R:7, G:7, B:7)\n" +
            "(R:11, G:11, B:11) (R:14, G:14, B:14) (R:17, G:17, B:17)\n" +
            "(R:21, G:21, B:21) (R:24, G:24, B:24) (R:27, G:27, B:27)\n", image.toString());
  }

  @Test
  public void testGreenComponent() {
    image.greenComponent();
    assertEquals("3 3\n" +
            "(R:2, G:2, B:2) (R:5, G:5, B:5) (R:8, G:8, B:8)\n" +
            "(R:12, G:12, B:12) (R:15, G:15, B:15) (R:18, G:18, B:18)\n" +
            "(R:22, G:22, B:22) (R:25, G:25, B:25) (R:28, G:28, B:28)\n", image.toString());
  }

  @Test
  public void testIntensity() {
    image.intensity();
    assertEquals("3 3\n" +
            "(R:2, G:2, B:2) (R:5, G:5, B:5) (R:8, G:8, B:8)\n" +
            "(R:12, G:12, B:12) (R:15, G:15, B:15) (R:18, G:18, B:18)\n" +
            "(R:22, G:22, B:22) (R:25, G:25, B:25) (R:28, G:28, B:28)\n", image.toString());
  }

  @Test
  public void testLuma() {
    image.luma();
    assertEquals("3 3\n" +
            "(R:1, G:1, B:1) (R:4, G:4, B:4) (R:7, G:7, B:7)\n" +
            "(R:11, G:11, B:11) (R:14, G:14, B:14) (R:17, G:17, B:17)\n" +
            "(R:21, G:21, B:21) (R:24, G:24, B:24) (R:27, G:27, B:27)\n", image.toString());
  }

  @Test
  public void testValue() {
    image.value();
    assertEquals("3 3\n" +
            "(R:3, G:3, B:3) (R:6, G:6, B:6) (R:9, G:9, B:9)\n" +
            "(R:13, G:13, B:13) (R:16, G:16, B:16) (R:19, G:19, B:19)\n" +
            "(R:23, G:23, B:23) (R:26, G:26, B:26) (R:29, G:29, B:29)\n", image.toString());
  }

  @Test
  public void testLoad() {
    Readable rd = new StringReader("load /Users/juliaouritskaya/Desktop/CS 3500/Assignment4/" +
            "koala-blue-greyscale.ppm");
    Appendable ap = new StringBuilder();
    ImageController cont = new ImageController(rd, ap);
    cont.control();
    String expected = "Welcome to the image processing program!\n"
            + "Supported user operations are: \n"
            + "load image-path image-name (load an image)\n"
            + "save image-path image-name (save an image)\n"
            + "red-component image-name dest-image-name "
            + "(create greyscale image with the red component)\n"
            + "green-component image-name dest-image-name "
            + "(create greyscale image with the green component)\n"
            + "blue-component image-name dest-image-name "
            + "(create greyscale image with the blue component)\n"
            + "intensity image-name dest-image-name "
            + "(create greyscale image with the intensity component)\n"
            + "luma image-name dest-image-name (create greyscale image with the luma component)\n"
            + "value image-name dest-image-name (create greyscale image with the value component)\n"
            + "horizontal-flip image-name dest-image-name (flips image horizontally)\n"
            + "vertical-flip image-name dest-image-name (flips image vertically)\n"
            + "brighten increment image-name dest-image-name (brighten or darken an image)\n"
            + "menu (Print supported instruction list)\n"
            + "q or quit (quit the program) \n"
            + "Type operation: Loading file.\n"
            + "File loaded.\n"
            + "Thank you for using this program!";
    assertEquals(expected, ap.toString());
  }

  @Test
  public void testLoad1() {
    System.out.println("load");
    String imagePath = "koala-blue-greyscale.ppm";
    String imageName = "Koala";
    ProcessingModelImpl instance = new ProcessingModelImpl();
    instance.load(imagePath, imageName);
    Image image = instance.getImage(imageName);
    int red = image.getPixels()[100][100].getRed();
    int green = image.getPixels()[100][100].getGreen();
    int blue = image.getPixels()[100][100].getBlue();
    assertEquals(red, 60);
    assertEquals(green, 60);
    assertEquals(blue, 60);
  }

  @Test
  public void testSave() {
    System.out.println("save");
    String imagePath = "koala-blue-greyscale.ppm";
    String imagePaths = "koala-blue-greyscale2.ppm";
    String imageName = "Koala";
    ProcessingModelImpl instance = new ProcessingModelImpl();
    instance.load(imagePath, imageName);
    File f = new File(imagePaths);
    if (f.exists()) {
      f.delete();
    }
    instance.save(imagePaths, imageName);
    assertTrue(f.exists());
  }
}